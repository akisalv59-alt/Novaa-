# NOVA STORE — Mise en ligne depuis iPhone

Ce projet est une **démo**, sans paiement ni expédition. Il ne faut pas le présenter comme une boutique prête à vendre.

## Option recommandée : GitHub + Render

1. Créer un compte sur github.com et render.com depuis Safari.
2. Sur GitHub, créer un dépôt privé nommé `nova-store`.
3. Importer les fichiers de ce dossier **à la racine du dépôt** : `main.py`, `requirements.txt`, `render.yaml`, les dossiers `static` et `templates`. Si GitHub mobile ne permet pas d'importer facilement un dossier ZIP, utiliser l'application Working Copy ou un ordinateur une seule fois.
4. Sur Render, ouvrir **New > Blueprint**, connecter GitHub et sélectionner le dépôt. Render lit `render.yaml`.
5. Valider le déploiement. Render fournit une URL du type `https://nova-store-demo-xxxx.onrender.com` (l'adresse exacte n'est connue qu'après création).
6. Ouvrir cette URL dans Safari puis **Partager > Sur l'écran d'accueil** pour l'utiliser comme une app.

### Limites

- Le plan gratuit de Render peut se mettre en veille, et ses caractéristiques peuvent évoluer.
- Le stockage SQLite local est **éphémère** sur ce type d'hébergement : les brouillons de commande peuvent disparaître après redémarrage/déploiement. Ne pas utiliser cette base pour de vraies commandes.
- Aucune interface administrateur authentifiée n'est incluse. La gestion des produits sur téléphone nécessitera une version ultérieure avec base PostgreSQL persistante et authentification.
- Aucun paiement Stripe ni synchronisation AliExpress n'est intégré.
